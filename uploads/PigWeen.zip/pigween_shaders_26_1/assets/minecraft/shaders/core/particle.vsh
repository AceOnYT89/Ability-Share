#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

in vec3 Position;
in vec2 UV0;
in vec4 Color;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec2 texCoord0;
out vec4 vertexColor;

bool inRange(float v, float lo, float hi) {
    return v >= lo - 0.004 && v <= hi + 0.004;
}

// Pigween: totem particles -> orange & dark purple (see the 1.21.11 version in the main pack)
vec4 pigweenTotem(vec4 c) {
    bool yellow = inRange(c.r, 0.6, 0.8) && inRange(c.g, 0.6, 0.9) && inRange(c.b, 0.0, 0.2);
    bool green  = inRange(c.r, 0.1, 0.3) && inRange(c.g, 0.4, 0.7) && inRange(c.b, 0.0, 0.2);
    if (yellow) {
        return vec4(1.0, 0.45 + (c.g - 0.6) * 0.5, 0.04, c.a);
    }
    if (green) {
        if (c.g >= 0.55) {
            return vec4(0.95 + (c.r - 0.1) * 0.25, 0.30 + (c.g - 0.55) * 0.8, 0.02, c.a);
        }
        return vec4(0.30 + (c.r - 0.1) * 0.5, 0.05 + c.b * 0.25, 0.42 + (c.g - 0.4) * 0.8, c.a);
    }
    return c;
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    texCoord0 = UV0;
    vertexColor = pigweenTotem(Color) * sample_lightmap(Sampler2, UV2);
}
