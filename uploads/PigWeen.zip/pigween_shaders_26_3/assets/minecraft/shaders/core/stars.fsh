#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:dynamictransforms.glsl>

layout(location = 0) out vec4 fragColor;

void main() {
    // Pigween: no stars, the day sky is shown 24/7
    discard;
}
